# MinexAI: An Open-Source, Cross-Platform GUI for Geochemical and Mineral Exploration Data Analysis and Visualization Using AI
